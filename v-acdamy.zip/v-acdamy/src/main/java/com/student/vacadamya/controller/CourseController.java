package com.student.vacadamya.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.vacadamya.mappers.CourseEntityToCourseResponseMapper;
import com.student.vacadamya.mappers.CourseRequestToCourseBOMapper;
import com.student.vacadamya.model.DepartmentResponse;
import com.student.vacadamya.model.CourseRequest;
import com.student.vacadamya.model.CourseResponse;
import com.student.vacadamya.model.dao.DepartmentEntity;
import com.student.vacadamya.model.dao.CourseEntity;
import com.student.vacadamya.service.DepartmentService;
import com.student.vacadamya.service.CourseService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j

public class CourseController {

    private CourseService courseService;

    private DepartmentService departmentService;

    private CourseRequestToCourseBOMapper courseRequestToCourseBOMapper;

    private CourseEntityToCourseResponseMapper courseEntityToCourseResponseMapper;

    @Autowired
    public CourseController(CourseService courseService,
                             CourseRequestToCourseBOMapper courseRequestToCurseBOMapper,
                             CourseEntityToCourseResponseMapper courseEntityToCourseResponseMapper) {

        this.courseService = courseService;
        this.courseRequestToCourseBOMapper = courseRequestToCourseBOMapper;
        this.courseEntityToCourseResponseMapper = courseEntityToCourseResponseMapper;
    }


    @RequestMapping("/getCourseByName/{SubjectName}")
    public CourseResponse getCourseByName(@PathVariable String SubjectName){
        final CourseEntity courseByName = courseService.getCourseByName(SubjectName);
        log.info("Course by name {}",courseByName);
        return courseEntityToCourseResponseMapper.courseEntityToCourseResponse(courseByName);
    }

    @RequestMapping("/saveCourse")
    public void getCourseByName(@RequestBody CourseRequest courseRequest){
        courseService.saveCourse(courseRequestToCourseBOMapper.courseRequestToCourseBO(courseRequest));
    }

}
