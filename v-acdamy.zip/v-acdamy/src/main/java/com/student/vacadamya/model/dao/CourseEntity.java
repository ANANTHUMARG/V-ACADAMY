package com.student.vacadamya.model.dao;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name="VACADAMY_COURSES")

public class CourseEntity {
		    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    @Column(name="subject_name")
	    private String SubjectName;
	    @Column(name="course_details")
	    private String CourseDetails;
	    @OneToOne(cascade = CascadeType.REMOVE)
	    @JoinColumn(name="dept_Id")
	    private DepartmentEntity departmentEntity;
	}


