package com.student.vacadamya.model.bo;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CourseBO {
	

	    private Long  id;
	    @NotBlank(message = "SubjectName cannot be blank")
	    private String SubjectName;
	    @NotBlank(message = "CourseDetails cannot be blank")
	    private String  CourseDetails;
	    @NotBlank(message = "Department cannot be blank")
	    private DepartmentBO departmentBO;

}
