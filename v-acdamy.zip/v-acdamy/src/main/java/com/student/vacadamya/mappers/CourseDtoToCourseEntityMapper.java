package com.student.vacadamya.mappers;

import org.mapstruct.Mapper;

import org.mapstruct.Mapping;

import com.student.vacadamya.model.dao.DepartmentDto;
//import com.student.vacadamya.model.dao.DepartmentEntity;
import com.student.vacadamya.model.dao.CourseDto;
import com.student.vacadamya.model.dao.CourseEntity;

@Mapper(componentModel = "spring")
public interface CourseDtoToCourseEntityMapper {
	 @Mapping(source = "departmentDto", target="departmentEntity")
	    CourseEntity CourseBOToCourseDao(CourseDto courseDto);
	    CourseEntity CourseBOToCourseDao(DepartmentDto departmentDto);

}
