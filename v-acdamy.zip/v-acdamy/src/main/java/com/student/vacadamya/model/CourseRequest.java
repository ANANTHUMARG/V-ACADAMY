package com.student.vacadamya.model;

import java.util.Optional;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class CourseRequest {


	    private Optional<Long>  id;
	    
	    @NotBlank(message = "SubjectName cannot be blank")
	    private Optional<String>  SubjectName;
	   
	    @NotBlank(message = "Department cannot be blank")
	    private Optional<DepartmentRequest> departmentRequest;

	    public Optional<Long> getId() {
	        if(Optional.ofNullable(id).isPresent()){

	            return Optional.ofNullable(id).get();
	        }
	        return Optional.empty();
	    }

	    
	    public Optional<String> getSubjectName() {
	        return Optional.ofNullable(SubjectName).get();
	    }

	    
	    public Optional<DepartmentRequest> getDepartmentRequest() {
	        return Optional.ofNullable(departmentRequest).get();
	    }

}
