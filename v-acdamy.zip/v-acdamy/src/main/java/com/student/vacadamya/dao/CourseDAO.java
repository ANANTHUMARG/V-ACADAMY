package com.student.vacadamya.dao;


import com.student.vacadamya.model.dao.CourseEntity;
import com.student.vacadamya.model.dao.CourseDto;


public interface CourseDAO {

	   CourseEntity getCourseByName(final String SubjectName);

	    void saveCourse(final CourseDto courseDto);
}
