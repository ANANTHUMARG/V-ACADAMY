package com.student.vacadamya.service;

import com.student.vacadamya.model.bo.CourseBO;
import com.student.vacadamya.model.dao.CourseEntity;

public interface CourseService {
	CourseEntity getCourseByName(final String SubjectName);

    void saveCourse(final CourseBO courseDto);
}
