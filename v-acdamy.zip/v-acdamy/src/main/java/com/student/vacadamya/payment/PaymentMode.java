package com.student.vacadamya.payment;

public enum PaymentMode {
	

	    NB,DC,CC
	}

