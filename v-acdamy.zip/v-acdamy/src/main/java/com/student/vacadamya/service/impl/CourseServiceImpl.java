package com.student.vacadamya.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.student.vacadamya.dao.CourseDAO;
import com.student.vacadamya.mappers.CourseBOToCourseDtoMapper;
//import com.student.vacadamya.mappers.CourseRequestToCourseBOMapper;
import com.student.vacadamya.model.bo.CourseBO;
import com.student.vacadamya.model.dao.CourseEntity;
import com.student.vacadamya.service.CourseService;

public class CourseServiceImpl implements CourseService {

	
	private final CourseDAO courseDAO;

  //  private CourseRequestToCourseBOMapper courseRequestToCourseBOMapper;

    private CourseBOToCourseDtoMapper courseBOToCourseDtoMapper;

    @Autowired
    public CourseServiceImpl(CourseDAO courseDAO,
                              CourseBOToCourseDtoMapper courseBOToCourseDtoMapper) {
        this.courseDAO = courseDAO;
        this.courseBOToCourseDtoMapper = courseBOToCourseDtoMapper;
    }
	@Override
	public CourseEntity getCourseByName(String SubjectName) {
		
		return courseDAO.getCourseByName(SubjectName);
	}

	@Override
	public void saveCourse(CourseBO courseBO) {
		 courseDAO.saveCourse(
	                courseBOToCourseDtoMapper.map(courseBO));
	}

}
