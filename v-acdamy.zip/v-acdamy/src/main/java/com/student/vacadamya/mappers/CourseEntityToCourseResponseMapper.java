package com.student.vacadamya.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.student.vacadamya.model.DepartmentResponse;
import com.student.vacadamya.model.CourseResponse;
import com.student.vacadamya.model.dao.DepartmentEntity;
import com.student.vacadamya.model.dao.CourseEntity;

@Mapper(componentModel = "spring")
public interface CourseEntityToCourseResponseMapper {
	@Mapping(source="departmentEntity", target="departmentResponse")
    CourseResponse courseEntityToCourseResponse(CourseEntity courseEntity);

    DepartmentResponse departmentEntityToDepartmentResponse(DepartmentEntity departmentEntity);
}
