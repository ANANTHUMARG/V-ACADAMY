package com.student.vacadamya.payment;

public enum PaymentStatus {
	 Pending,Failed,Success;
}


   