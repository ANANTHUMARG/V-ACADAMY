package com.student.vacadamya.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.student.vacadamya.model.bo.DepartmentBO;
import com.student.vacadamya.model.bo.CourseBO;
import com.student.vacadamya.model.dao.DepartmentDto;
import com.student.vacadamya.model.dao.CourseDto;

@Mapper(componentModel = "spring")
public interface CourseBOToCourseDtoMapper {
	@Mapping(source = "id", target = "id")
    @Mapping(source = "SubjectName", target = "SubjectName")
    @Mapping(source = "departmentBO", target = "departmentDto")

    CourseDto map(CourseBO courseBO);

    @Mapping(source = "deptId", target = "deptId", qualifiedByName = "unwrap")
    @Mapping(source = "deptName", target = "deptName", qualifiedByName = "unwrap")
    DepartmentDto departmentBOToDepartmentDto(DepartmentBO departmentBO);
}
