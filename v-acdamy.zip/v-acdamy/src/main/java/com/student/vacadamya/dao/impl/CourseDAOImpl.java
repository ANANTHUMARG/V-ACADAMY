package com.student.vacadamya.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.student.vacadamya.dao.CourseDAO;
import com.student.vacadamya.dao.CourseCRUDRepository;
import com.student.vacadamya.mappers.CourseDtoToCourseEntityMapper;
import com.student.vacadamya.model.dao.CourseDto;
import com.student.vacadamya.model.dao.CourseEntity;
import com.student.vacadamya.model.dao.StudentEntity;

@Repository
public class CourseDAOImpl implements CourseDAO {

	private final CourseCRUDRepository courseCRUDRepository;

    private CourseDtoToCourseEntityMapper courseBOToCourseDaoMapper;

    @Autowired
    public CourseDAOImpl(CourseCRUDRepository courseCRUDRepository,
                          CourseDtoToCourseEntityMapper courseBOToCourseDaoMapper) {
        this.courseCRUDRepository = courseCRUDRepository;
        this.courseBOToCourseDaoMapper = courseBOToCourseDaoMapper;
    }
	
	@Override
	public CourseEntity getCourseByName(String SubjectName) {
		return courseCRUDRepository.getCourseByName(SubjectName);
		
	}

	@Override
	public void saveCourse(CourseDto courseDto) {
		final CourseEntity courseEntity = courseBOToCourseDaoMapper.CourseBOToCourseDao(courseDto);
        courseCRUDRepository.save(courseEntity);

	}

}
