package com.student.vacadamya.service;

import com.student.vacadamya.model.dao.DepartmentEntity;
//import com.student.vacadamya.model.dao.StudentEntity;


public interface DepartmentService {

    public DepartmentEntity getDepartmentById(final Long id);

}
