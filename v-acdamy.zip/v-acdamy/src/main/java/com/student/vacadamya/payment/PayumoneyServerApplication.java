package com.student.vacadamya.payment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
@SpringBootApplication

public class PayumoneyServerApplication extends SpringBootServletInitializer{
	private static Class applicationClass = PayumoneyServerApplication.class;

	public static void main(String[] args) {
		SpringApplication.run(PayumoneyServerApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(applicationClass);
	}
}
