package com.student.vacadamya.payment;

public interface PaymentService {
	PaymentDetail proceedPayment(PaymentDetail paymentDetail);
	String payuCallback(PaymentCallback paymentResponse);
}
