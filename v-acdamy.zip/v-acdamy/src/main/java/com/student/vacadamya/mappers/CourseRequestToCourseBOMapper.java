package com.student.vacadamya.mappers;

import java.util.Optional;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import com.student.vacadamya.model.DepartmentRequest;
import com.student.vacadamya.model.CourseRequest;
import com.student.vacadamya.model.bo.DepartmentBO;
import com.student.vacadamya.model.bo.CourseBO;

@Mapper(componentModel = "spring")
public interface CourseRequestToCourseBOMapper {
	 @Mapping(source = "id", target = "id", qualifiedByName = "unwrap")
	    @Mapping(source = "SubjectName", target = "SubjectName", qualifiedByName = "unwrap")
	    
	    @Mapping(source = "departmentRequest", target = "departmentBO", qualifiedByName = "unwrap")
	    CourseBO courseRequestToCourseBO(CourseRequest courseRequest);

	    @Mapping(source = "deptId", target = "deptId", qualifiedByName = "unwrap")
	    @Mapping(source = "deptName", target = "deptName", qualifiedByName = "unwrap")
	    DepartmentBO courseRequestToDepartementBo(DepartmentRequest departmentRequest);

	    @Named("unwrap")
	    default <T> T unwrap(Optional<T> optional) {
	        if(optional!= null && optional.isPresent()) {
	            return optional.get();
	        }
	        return null;
	    }

}
