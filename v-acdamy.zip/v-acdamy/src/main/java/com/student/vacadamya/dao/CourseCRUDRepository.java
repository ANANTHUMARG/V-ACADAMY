package com.student.vacadamya.dao;

import org.springframework.data.repository.CrudRepository;

import com.student.vacadamya.model.dao.CourseEntity;

public interface CourseCRUDRepository extends CrudRepository<CourseEntity, Long> {
	 CourseEntity getCourseByName(final String SubjectName);
}
