package com.student.vacadamya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VAcadamyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
